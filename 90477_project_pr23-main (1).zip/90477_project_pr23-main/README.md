# 90477_project_pr23

Project Software Maintainability Predictions P23, 'Deep Learning Approach for Software Maintainability Metrics Prediction' 
Paper: https://ieeexplore.ieee.org/document/8698760
Datasets: https://zenodo.org/record/3693686#.Ya8-lfnMI2w
