https://machinelearningmastery.com/feature-selection-machine-learning-python/#:~:text=Feature%20selection%20is%20a%20process,in%20which%20you%20are%20interested.&text=Improves%20Accuracy%3A%20Less%20misleading%20data,means%20that%20algorithms%20train%20faster.
-
-
https://support.minitab.com/en-us/minitab-express/1/help-and-how-to/modeling-statistics/regression/supporting-topics/basics/a-comparison-of-the-pearson-and-spearman-correlation-methods/#:~:text=The%20Pearson%20correlation%20evaluates%20the%20linear%20relationship%20between%20two%20continuous%20variables.&text=The%20Spearman%20correlation%20coefficient%20is,evaluate%20relationships%20involving%20ordinal%20variables.
-
-
http://rasbt.github.io/mlxtend/user_guide/classifier/OneRClassifier/
-
-
https://www.sciencedirect.com/science/article/pii/S1532046418301400
-
-
Paper: https://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.645.151&rep=rep1&type=pdf
Library: https://github.com/oulenz/fuzzy-rough-learn
-
-
https://keras.io/
https://colah.github.io/posts/2015-08-Understanding-LSTMs/
https://keras.io/api/layers/recurrent_layers/lstm/
